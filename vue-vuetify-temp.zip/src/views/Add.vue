<template>
    <v-container grid-list-xs>        
        <v-sheet max-width="300" class="mx-auto">
            
            <v-text-field
                v-model="milk_number"
                label="เลขไมต์"
            ></v-text-field>
            
            <v-text-field
                v-model="bill_amout"
                label="จำนวนเงิน"
            ></v-text-field>

            <v-btn
                color="success"
                class="mt-4"
                block
            >
            บันทึกบิล
            </v-btn>
            
        </v-sheet>
    </v-container>
</template>

<script setup lang="ts">

    import { ref } from 'vue'

    let milk_number = ref(0)
    let bill_amout = ref(0)


</script>

<style scoped>

</style>